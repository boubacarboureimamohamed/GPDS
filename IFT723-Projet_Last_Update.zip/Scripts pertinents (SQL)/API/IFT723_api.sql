/*
-- ===========================================================================
-- IFT723_api.sql
-- ---------------------------------------------------------------------------
Activité : IFT187_2023-1
Encodage : UTF-8, sans BOM; fin de ligne Unix (LF)
Plateforme : PostgreSQL 16
Responsable : Mohamed.Boubacar.Boureima@usherbrooke.ca 
              Othman.El.Biyaali@USherbrooke.ca 
              Alseny.Toumany.Soumah@usherbrooke.ca
              Maxime.Sourceaux@usherbrooke.ca 
Version : 1.0
Statut : en vigueur
Résumé : Création de l'API de la base de données
-- ===========================================================================
*/




-- Définition du schéma
create schema if not exists "IFT723";
set schema 'IFT723';

-- DONE 2023-12-20 (ELBO1901)-(BOUM3688)-(SOUM3004)-(SOUA2604) Placer une API standardisée dans un contexte ÉMIR.

-- Adresse table courante
--Insertion
CREATE OR REPLACE PROCEDURE Adresse_Courant_ins(
  adresseID_ INT,
	appartement_ Adresse_Appartement,
	rue_ Adresse_Rue,
	ville_ Adresse_Ville,
	region_ Adresse_Region,
	code_postal_ Adresse_CP,
	pays_ Adresse_Pays,
	date_ajout_ Estampille
	)
AS $$
BEGIN
  CALL Adresse_Courante_ajout_at(
      	adresseID_,
	    appartement_,
	    rue_,
	    ville_,
	    region_,
	    code_postal_,
	    pays_,
	    date_ajout_
      );
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE PROCEDURE Adresse_Courant_now_ins(
  adresseID_ INT,
	appartement_ Adresse_Appartement,
	rue_ Adresse_Rue,
	ville_ Adresse_Ville,
	region_ Adresse_Region,
	code_postal_ Adresse_CP,
	pays_ Adresse_Pays
	)
AS $$
BEGIN
  CALL Adresse_Courante_ajout_now(
      adresseID_,
	    appartement_,
	    rue_,
	    ville_,
	    region_,
	    code_postal_,
	    pays_
      );
END;
$$ LANGUAGE plpgsql;

--Modification
CREATE OR REPLACE PROCEDURE Adresse_Courant_Localisation_mod(
  adresseID_ INT,
	appartement_ Adresse_Appartement,
	rue_ Adresse_Rue,
	ville_ Adresse_Ville,
	region_ Adresse_Region,
	code_postal_ Adresse_CP,
	pays_ Adresse_Pays,
	date_changement Estampille
	)
AS $$
BEGIN
  CALL Adresse_Courante_modifier_Localisation_at(
      adresseID_,
	    appartement_,
	    rue_,
	    ville_,
	    region_,
	    code_postal_,
	    pays_,
      date_changement
      );
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE PROCEDURE Adresse_Courante_Localisation_now_mod(
  adresseID_ INT,
	appartement_ Adresse_Appartement,
	rue_ Adresse_Rue,
	ville_ Adresse_Ville,
	region_ Adresse_Region,
	code_postal_ Adresse_CP,
	pays_ Adresse_Pays
	)
AS $$
BEGIN
  CALL Adresse_Courante_modifier_Localisation_now(
      adresseID_,
	    appartement_,
	    rue_,
	    ville_,
	    region_,
	    code_postal_,
	    pays_
      );
END;
$$ LANGUAGE plpgsql;

--Retrait
CREATE OR REPLACE PROCEDURE Adresse_Courante_ret(
  adresseID_ INT,
	date_retrait_ Estampille
	)
AS $$
BEGIN
  CALL Adresse_Courante_retrait_at(
      adresseID_,
	    date_retrait_
      );
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE PROCEDURE Adresse_Courante_now_ret(
  adresseID_ INT
	)
AS $$
BEGIN
  CALL Adresse_Courante_retrait_now(
      adresseID_
      );
END;
$$ LANGUAGE plpgsql;


-- Adresse table validite
--Insertion
CREATE OR REPLACE PROCEDURE adresse_validite_ins(
    adresseID_ INT,
	  appartement_ Adresse_Appartement,
	  rue_ Adresse_Rue,
	  ville_ Adresse_Ville,
	  region_ Adresse_Region,
	  code_postal_ Adresse_CP,
	  pays_ Adresse_Pays,
	  date_debut_ Estampille,
	  date_fin_ Estampille
)
AS $$
BEGIN
  CALL adresse_validite_ajout(
      adresseID_,
	    appartement_,
	    rue_,
	    ville_,
	    region_,
	    code_postal_,
	    pays_,
	    date_debut_,
	    date_fin_
      );
END;
$$ LANGUAGE plpgsql;



-- Modification
CREATE OR REPLACE PROCEDURE adresse_validite_mod(
    adresseID_ INT,
	  appartement_ Adresse_Appartement,
	  rue_ Adresse_Rue,
	  ville_ Adresse_Ville,
	  region_ Adresse_Region,
	  code_postal_ Adresse_CP,
	  pays_ Adresse_Pays,
	  date_debut_ Estampille,
	  date_fin_ Estampille
  )
AS $$
BEGIN
  CALL adresse_validite_modification(
      adresseID_,
	    appartement_,
	    rue_,
	    ville_,
	    region_,
	    code_postal_,
	    pays_,
	    date_debut_,
	    date_fin_
      );
END;
$$ LANGUAGE plpgsql;


-- Retrait
CREATE OR REPLACE PROCEDURE adresse_validite_ret(
  adresseID_ INT,
	date_effacement_debut_ Estampille,
	date_effacement_fin_ Estampille
	)
AS $$
BEGIN
  CALL adresse_validite_effacer(
      adresseID_,
	    date_effacement_debut_,
	    date_effacement_fin_
      );
END;
$$ LANGUAGE plpgsql;



-- Etudiant table courante
--Insertion
CREATE OR REPLACE PROCEDURE etudiant_courante_ins(
	matricule_ Etudiant_Matricule,
	prenom_ nom_prenom, 
	nom_ nom_prenom, 
	courriel_ email, 
	telephone_ phoneNumber,
	adresseID_ INT,
	date_ajout_ Estampille
	)
AS $$
BEGIN
  CALL etudiant_courante_ajout_at(
    	matricule_,
		prenom_, 
		nom_, 
		courriel_, 
		telephone_,
		adresseID_,
		date_ajout_
    	);
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE PROCEDURE etudiant_courante_now_ins(
	matricule_ Etudiant_Matricule,
	prenom_ nom_prenom, 
	nom_ nom_prenom, 
	courriel_ email, 
	telephone_ phoneNumber,
	adresseID_ INT
	)
AS $$
BEGIN
  CALL etudiant_courante_ajout_at(
    	matricule_,
		prenom_, 
		nom_, 
		courriel_, 
		telephone_,
		adresseID_
    	);
END;
$$ LANGUAGE plpgsql;


--Modification
CREATE OR REPLACE PROCEDURE etudiant_courante_nom_prenom_mod(
	matricule_ Etudiant_Matricule,
	prenom_ nom_prenom, 
	nom_ nom_prenom, 
	date_changement Estampille
	)
AS $$
BEGIN
  CALL etudiant_courante_modifier_contact_at(
    	matricule_,
		prenom_, 
		nom_, 
		date_changement
    	);
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE PROCEDURE etudiant_courant_nom_prenom_now_mod(
	matricule_ Etudiant_Matricule,
	prenom_ nom_prenom, 
	nom_ nom_prenom
	)
AS $$
BEGIN
  CALL etudiant_courante_modifier_nom_prenom_now(
    	matricule_,
		prenom_, 
		nom_
    	);
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE PROCEDURE etudiant_courant_contact_mod(
	matricule_ Etudiant_Matricule,
	courriel_ email, 
	telephone_ phoneNumber, 
	date_changement Estampille
	)
AS $$
BEGIN
  CALL etudiant_courante_modifier_contact_at(
    	matricule_,
		courriel_, 
		telephone_, 
		date_changement
    	);
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE PROCEDURE etudiant_courant_contact_now_mod(
	matricule_ Etudiant_Matricule,
	courriel_ email, 
	telephone_ phoneNumber
	)
AS $$
BEGIN
  CALL etudiant_courante_modifier_contact_now(
    	matricule_,
		courriel_, 
		telephone_
    	);
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE PROCEDURE etudiant_courant_adresseID_mod(
	matricule_ Etudiant_Matricule,
	adresseID_ INT, 
	date_changement Estampille
	)
AS $$
BEGIN
  CALL etudiant_courante_modifier_adresseID_at(
    	matricule_,
		adresseID_, 
		date_changement
    	);
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE PROCEDURE etudiant_courant_adresseID_now_mod(
	matricule_ Etudiant_Matricule,
	adresseID_ INT
	)
AS $$
BEGIN
  CALL etudiant_courante_modifier_adresseID_now(
    	matricule_,
		adresseID_
    	);
END;
$$ LANGUAGE plpgsql;

-- Retrait
CREATE OR REPLACE PROCEDURE etudiant_courant_ret(
	matricule_ Etudiant_Matricule,
	date_retrait_ Estampille
	)
AS $$
BEGIN
  CALL etudiant_courante_retrait_at(
    	matricule_,
		date_retrait_
    	);
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE PROCEDURE etudiant_courant_now_ret(
	matricule_ Etudiant_Matricule
	)
AS $$
BEGIN
  CALL etudiant_courante_retrait_now(
    	matricule_
    	);
END;
$$ LANGUAGE plpgsql;

-- Etudiant table validite
--Insertion
CREATE OR REPLACE PROCEDURE etudiant_validite_ins(
	matricule_ Etudiant_Matricule,
	prenom_ nom_prenom, 
	nom_ nom_prenom, 
	courriel_ email, 
	telephone_ phoneNumber,
	adresseID_ INT,
	date_debut_ Estampille,
	date_fin_ Estampille
	)
AS $$
BEGIN
  CALL etudiant_validite_ajout(
    	matricule_,
		prenom_, 
		nom_, 
		courriel_, 
		telephone_,
		adresseID_,
		date_debut_,
		date_fin_
    	);
END;
$$ LANGUAGE plpgsql;


--Modification
CREATE OR REPLACE PROCEDURE etudiant_validite_mod(
	matricule_ Etudiant_Matricule,
	prenom_ nom_prenom, 
	nom_ nom_prenom, 
	courriel_ email, 
	telephone_ phoneNumber,
	adresseID_ INT,
	date_debut_ Estampille,
	date_fin_ Estampille
	)
AS $$
BEGIN
  CALL etudiant_validite_modification(
    	matricule_,
		prenom_, 
		nom_, 
		courriel_, 
		telephone_,
		adresseID_,
		date_debut_,
		date_fin_
    	);
END;
$$ LANGUAGE plpgsql;

-- Retrait
CREATE OR REPLACE PROCEDURE etudiant_validite_ret(
	matricule_ Etudiant_Matricule,
	date_effacement_debut_ Estampille,
	date_effacement_fin_ Estampille
	)
AS $$
BEGIN
  CALL etudiant_validite_effacer(
    	matricule_,
		date_effacement_debut_,
		date_effacement_fin_
    	);
END;
$$ LANGUAGE plpgsql;

/*
-- ===========================================================================
Contributeurs :
(BOUM3688) Mohamed.Boubacar.Boureima@usherbrooke.ca 
(ELBO1901) Othman.El.Biyaali@USherbrooke.ca 
(SOUA2604) Alseny.Toumany.Soumah@usherbrooke.ca
(SOUM3004) Maxime.Sourceaux@usherbrooke.ca 

Adresse, droits d'auteur et copyright :
  Département d'informatique
  Faculté des sciences
  Université de Sherbrooke
  Sherbrooke (Québec)  J1K 2R1
  Canada
-- ===========================================================================
*/
