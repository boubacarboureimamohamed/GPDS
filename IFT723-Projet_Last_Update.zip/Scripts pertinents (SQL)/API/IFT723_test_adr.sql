/*
-- ===========================================================================
-- IFT723_test_adr.sql
-- ---------------------------------------------------------------------------
Activité : IFT187_2023-1
Encodage : UTF-8, sans BOM; fin de ligne Unix (LF)
Plateforme : PostgreSQL 16
Responsable : Mohamed.Boubacar.Boureima@usherbrooke.ca 
              Othman.El.Biyaali@USherbrooke.ca 
              Alseny.Toumany.Soumah@usherbrooke.ca
              Maxime.Sourceaux@usherbrooke.ca 
Version : 1.0
Statut : en vigueur
Résumé : Permet de tester les fonctions de l'API relative aux tables Adresse
-- ===========================================================================
*/



SET SCHEMA 'IFT723';

--Fonction d'ajout dans la table courante
--CALL Adresse_Courante_ins(1, '1', 'testRue', 'testVille', 'Qc',  'A1A 1A1', 'CA', '2017-06-22 19:10:25');
--CALL Adresse_Courante_now_ins(2, '2', 'testRue2', 'testVille2', 'Qc2',  'A2A 2A2', 'CA');

--Fonction de modification de la table courante
--CALL Adresse_Courante_Localisation_mod(1, '1', 'testRue_2', 'testVille_2', 'Qc_2',  'A1A 1A1', 'CA', '2019-06-22 19:10:25');
--CALL Adresse_Courante_Localisation_now_mod(2, '2', 'testRue2_2', 'testVille2_@', 'Qc2_2',  'A2A 2A2', 'CA');

--Fonction d'effacement de la table courante
--CALL Adresse_Courante_ret(1, '2020-06-22 19:10:25');
--CALL Adresse_Courante_now_ret(2);


--Fonction pour l'ajout dans les tables de validités
--CALL adresse_validite_ins(1, '1', 'testRue', 'testVille', 'Qc',  'A1A 1A1', 'CA', '2016-06-22 19:10:25', '2017-06-22 19:10:25');
--CALL adresse_validite_ins(1, '1', 'testRue', 'testVille', 'Qc',  'A1A 1A1', 'CA', '2018-06-22 19:10:25', '2019-06-22 19:10:25');

--Fonction pour forcer la résolution de données adjacentes des tables de validités
--CALL adresse_validite_ins(1, '1', 'testRue', 'testVille', 'Qc',  'A1A 1A1', 'CA', '2017-06-22 19:10:25', '2018-06-22 19:10:25');

--Fonction pour modifier les tables de validités
--CALL adresse_validite_mod(1, '1', 'testRue_2', 'testVille_2', 'Qc_2',  'A1A 1A1', 'CA', '2017-06-22 19:10:25', '2018-06-22 19:10:25');


--Fonction pour l'effacement des tables de validités
	--Si le nouveau range est contenu dans un autre element
	--Ancien   : ==========
	--Effacer  :    ====
	--Résultat : ===    ===
--CALL adresse_validite_ins(1, '1', 'testRue', 'testVille', 'Qc',  'A1A 1A1', 'CA', '2015-06-22 19:15:25','2018-06-22 19:15:25');	
--CALL adresse_validite_ret(1, '2016-06-22 19:15:25', '2017-06-22 19:15:25');

	
	--Si des elements sont contenus dans le range
	--Ancien 1 :     ====
	--Ancien 2 :		 =====
	--Effacer  :    ===========
	--Résultat :    	
--CALL adresse_validite_ins(1, '1', 'testRue', 'testVille', 'Qc',  'A1A 1A1', 'CA', '2015-06-22 19:15:25','2016-06-22 19:15:25');
--CALL adresse_validite_ins(1, '1', 'testRue', 'testVille', 'Qc',  'A1A 1A1', 'CA', '2017-06-22 19:15:25','2018-06-22 19:15:25');	
--CALL adresse_validite_ret(1, '2014-06-22 19:15:25', '2019-06-22 19:15:25');
	
	
	--S'il y a chevauchement & ne s'étend pas sur la droite
    --Ancien   : =======
	--Effacer  :      =====
	--Résultat : =====
--CALL adresse_validite_ins(1, '1', 'testRue', 'testVille', 'Qc',  'A1A 1A1', 'CA', '2017-06-22 19:15:25','2019-06-22 19:15:25');	
--CALL adresse_validite_ret(1, '2018-06-22 19:15:25', '2020-06-22 19:15:25');	
	
	
	--S'il y a chevauchement & ne s'étend pas sur la gauche
    --Ancien   :    =======
	--Effacer  : =====
	--Résultat :      =====
--CALL adresse_validite_ins(1, '1', 'testRue', 'testVille', 'Qc',  'A1A 1A1', 'CA', '2017-06-22 19:15:25','2019-06-22 19:15:25');	
--CALL adresse_validite_ret(1, '2016-06-22 19:15:25', '2018-06-22 19:15:25');	
	
	/*
-- ===========================================================================
Contributeurs :
(BOUM3688) Mohamed.Boubacar.Boureima@usherbrooke.ca 
(ELBO1901) Othman.El.Biyaali@USherbrooke.ca 
(SOUA2604) Alseny.Toumany.Soumah@usherbrooke.ca
(SOUM3004) Maxime.Sourceaux@usherbrooke.ca 

Adresse, droits d'auteur et copyright :
  Département d'informatique
  Faculté des sciences
  Université de Sherbrooke
  Sherbrooke (Québec)  J1K 2R1
  Canada
-- ===========================================================================
*/